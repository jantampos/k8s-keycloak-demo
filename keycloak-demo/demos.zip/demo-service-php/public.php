<?php
include 'headers.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    echo '{ "message": "public" }';
}
?>